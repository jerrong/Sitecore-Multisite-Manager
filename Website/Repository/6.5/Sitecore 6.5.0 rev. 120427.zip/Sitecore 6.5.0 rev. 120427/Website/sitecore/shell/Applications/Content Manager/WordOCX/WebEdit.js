﻿function InitWord(word, downloadUrl) {
   var url = downloadUrl + '&t=d.docx'; 
   word.Open(url);
}

function GetFieldValue(word, ) {
   
}
UPDATE "RolesInRoles"
SET
  "ApplicationName" = '1C3E8077ADB940168F06F27ED5695F3B'
WHERE
  "ApplicationName" IS NULL
/
exit

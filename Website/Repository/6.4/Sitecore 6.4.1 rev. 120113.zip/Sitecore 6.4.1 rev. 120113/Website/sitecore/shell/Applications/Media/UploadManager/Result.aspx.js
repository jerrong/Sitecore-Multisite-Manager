/* Sitecore.Result */

Sitecore.Result = new function() {
  Sitecore.Dhtml.attachEvent(window, "onload", function() { Sitecore.Result.load() } );
  
  this.load = function() {
  }
}
